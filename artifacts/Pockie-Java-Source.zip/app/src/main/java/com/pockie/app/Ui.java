package com.pockie.app;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public final class Ui {
  private static Typeface regular, semibold;
  public static final int BLACK = Color.rgb(3, 5, 5),
      BLUE = Color.rgb(20, 139, 255),
      GREEN = Color.rgb(0, 188, 120),
      RED = Color.rgb(255, 36, 45),
      MUTED = Color.rgb(78, 87, 96),
      FIELD = Color.rgb(234, 235, 239),
      CYAN = Color.rgb(194, 241, 252);

  private Ui() {}

  public static int dp(Context c, float value) {
    return Math.round(value * c.getResources().getDisplayMetrics().density);
  }

  public static class Icon extends View {
    String name;
    int color;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public Icon(Context context, AttributeSet attributes) {
      super(context, attributes);
      name = "grid";
      color = BLACK;
      setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public Icon(Context c, String name, int color) {
      super(c);
      this.name = name;
      this.color = color;
      setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setIconName(String name) {
      this.name = name;
      invalidate();
    }

    public void setIconColor(int color) {
      this.color = color;
      invalidate();
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2) {
      c.drawLine(x1, y1, x2, y2, p);
    }

    private void path(Canvas c, float... points) {
      Path a = new Path();
      a.moveTo(points[0], points[1]);
      for (int i = 2; i < points.length; i += 2) a.lineTo(points[i], points[i + 1]);
      c.drawPath(a, p);
    }

    @Override
    protected void onDraw(Canvas canvas) {
      super.onDraw(canvas);
      canvas.save();
      float s = Math.min(getWidth(), getHeight()) / 24f;
      canvas.translate((getWidth() - 24 * s) / 2, (getHeight() - 24 * s) / 2);
      canvas.scale(s, s);
      p.setColor(color);
      p.setStrokeWidth(1.8f);
      p.setStrokeCap(Paint.Cap.ROUND);
      p.setStrokeJoin(Paint.Join.ROUND);
      p.setStyle(Paint.Style.STROKE);
      switch (name) {
        case "back":
          path(canvas, 15, 5, 8, 12, 15, 19);
          break;
        case "next":
          path(canvas, 9, 7, 14, 12, 9, 17);
          break;
        case "down":
          path(canvas, 7, 10, 12, 15, 17, 10);
          break;
        case "search":
          canvas.drawCircle(10.5f, 10.5f, 6, p);
          line(canvas, 15, 15, 21, 21);
          break;
        case "plus":
          line(canvas, 12, 4, 12, 20);
          line(canvas, 4, 12, 20, 12);
          break;
        case "close":
          line(canvas, 7, 7, 17, 17);
          line(canvas, 17, 7, 7, 17);
          break;
        case "grid":
          p.setStyle(Paint.Style.FILL);
          for (int x = 0; x < 2; x++)
            for (int y = 0; y < 2; y++)
              canvas.drawRoundRect(4 + x * 10, 4 + y * 10, 10 + x * 10, 10 + y * 10, 2, 2, p);
          break;
        case "category":
          for (int x = 0; x < 2; x++)
            for (int y = 0; y < 2; y++) canvas.drawCircle(7 + x * 10, 7 + y * 10, 3, p);
          break;
        case "home":
          p.setStyle(Paint.Style.FILL);
          Path home = new Path();
          home.moveTo(4, 10);
          home.lineTo(12, 3);
          home.lineTo(20, 10);
          home.lineTo(20, 20);
          home.lineTo(4, 20);
          home.close();
          canvas.drawPath(home, p);
          p.setColor(Color.WHITE);
          canvas.drawRoundRect(10, 14, 14, 20, 1, 1, p);
          break;
        case "transactions":
        case "notes":
          canvas.drawRoundRect(5, 3, 19, 21, 2, 2, p);
          line(canvas, 8, 8, 16, 8);
          line(canvas, 8, 12, 16, 12);
          line(canvas, 8, 16, 13, 16);
          break;
        case "reports":
          p.setStyle(Paint.Style.FILL);
          canvas.drawRoundRect(4, 15, 7, 21, 1, 1, p);
          canvas.drawRoundRect(11, 11, 14, 21, 1, 1, p);
          canvas.drawRoundRect(18, 6, 21, 21, 1, 1, p);
          p.setStyle(Paint.Style.STROKE);
          path(canvas, 3, 11, 10, 8, 16, 3, 20, 3);
          break;
        case "bell":
          p.setStyle(Paint.Style.FILL);
          Path bell = new Path();
          bell.moveTo(6, 16);
          bell.lineTo(8, 8);
          bell.quadTo(12, 2, 16, 8);
          bell.lineTo(18, 16);
          bell.close();
          canvas.drawPath(bell, p);
          canvas.drawRoundRect(5, 16, 19, 18, 1, 1, p);
          canvas.drawCircle(12, 20, 1.5f, p);
          canvas.drawCircle(18, 4, 2, p);
          break;
        case "food":
          line(canvas, 6, 3, 6, 10);
          line(canvas, 3, 3, 3, 8);
          line(canvas, 9, 3, 9, 8);
          path(canvas, 3, 8, 6, 11, 9, 8);
          line(canvas, 6, 11, 6, 21);
          path(canvas, 17, 3, 14, 10, 18, 10, 18, 21);
          line(canvas, 18, 3, 18, 10);
          break;
        case "person":
          p.setStyle(Paint.Style.FILL);
          canvas.drawCircle(12, 7, 4, p);
          canvas.drawRoundRect(6, 13, 18, 21, 5, 5, p);
          break;
        case "shop":
          path(canvas, 3, 8, 5, 3, 19, 3, 21, 8);
          canvas.drawRoundRect(4, 8, 20, 21, 3, 3, p);
          path(canvas, 4, 9, 8, 12, 12, 9, 16, 12, 20, 9);
          line(canvas, 8, 17, 16, 17);
          break;
        case "cart":
          path(canvas, 2, 4, 5, 4, 8, 16, 19, 16, 22, 7, 6, 7);
          canvas.drawCircle(9, 21, 1, p);
          canvas.drawCircle(18, 21, 1, p);
          break;
        case "mail":
          canvas.drawRoundRect(3, 5, 21, 19, 3, 3, p);
          path(canvas, 4, 7, 12, 13, 20, 7);
          break;
        case "wallet":
          canvas.drawRoundRect(3, 5, 21, 20, 3, 3, p);
          canvas.drawRoundRect(14, 10, 22, 16, 2, 2, p);
          line(canvas, 5, 3, 17, 3);
          break;
        case "scan":
          path(canvas, 3, 8, 3, 3, 8, 3);
          path(canvas, 16, 3, 21, 3, 21, 8);
          path(canvas, 21, 16, 21, 21, 16, 21);
          path(canvas, 8, 21, 3, 21, 3, 16);
          line(canvas, 7, 8, 7, 16);
          line(canvas, 11, 8, 11, 16);
          line(canvas, 16, 8, 16, 16);
          line(canvas, 1, 12, 23, 12);
          break;
        case "calendar":
          canvas.drawRoundRect(3, 5, 21, 21, 3, 3, p);
          line(canvas, 3, 10, 21, 10);
          line(canvas, 8, 2, 8, 7);
          line(canvas, 16, 2, 16, 7);
          p.setStyle(Paint.Style.FILL);
          canvas.drawCircle(8, 14, 1, p);
          canvas.drawCircle(13, 14, 1, p);
          canvas.drawCircle(8, 18, 1, p);
          break;
        case "edit":
          path(canvas, 4, 17, 16, 5, 20, 9, 8, 21, 4, 21, 4, 17);
          line(canvas, 14, 7, 18, 11);
          break;
        case "delete":
          path(canvas, 6, 7, 7, 21, 17, 21, 18, 7);
          line(canvas, 4, 6, 20, 6);
          path(canvas, 9, 6, 9, 3, 15, 3, 15, 6);
          line(canvas, 10, 10, 10, 17);
          line(canvas, 14, 10, 14, 17);
          break;
        case "lock":
          canvas.drawRoundRect(5, 10, 19, 22, 3, 3, p);
          canvas.drawArc(8, 2, 16, 14, 180, 180, false, p);
          canvas.drawCircle(12, 15, 1, p);
          break;
        case "bank":
          path(canvas, 3, 8, 12, 2, 21, 8, 3, 8);
          line(canvas, 3, 21, 21, 21);
          line(canvas, 5, 10, 5, 18);
          line(canvas, 10, 10, 10, 18);
          line(canvas, 15, 10, 15, 18);
          line(canvas, 20, 10, 20, 18);
          break;
        case "wifi":
          canvas.drawArc(1, 4, 23, 23, 215, 110, false, p);
          canvas.drawArc(5, 9, 19, 24, 220, 100, false, p);
          canvas.drawCircle(12, 20, 1, p);
          break;
        case "check":
          path(canvas, 5, 12, 10, 17, 20, 6);
          break;
        case "rupee":
          line(canvas, 6, 4, 19, 4);
          line(canvas, 6, 8, 19, 8);
          path(canvas, 8, 4, 14, 4, 16, 8, 14, 12, 7, 12, 17, 21);
          break;
        case "transfer":
          path(canvas, 3, 8, 20, 8, 16, 4);
          path(canvas, 21, 16, 4, 16, 8, 20);
          break;
        default:
          canvas.drawCircle(12, 12, 8, p);
          break;
      }
      canvas.restore();
    }
  }
}
